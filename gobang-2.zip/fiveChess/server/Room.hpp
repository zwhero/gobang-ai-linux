#pragma once

#include <iostream>

using namespace std;

#define SIZE 15
#define BLACK 'X'
#define WHITE 'O'

class Room
{
private:
    uint32_t one;
    uint32_t two;
    uint32_t current;
    char piece[2];
    char board[SIZE][SIZE];
    char result; //X:第一个玩家赢  O:第二个玩家赢  E:平局  N:继续游戏

    pthread_mutex_t lock;

public:
    Room()
    {
    }
    Room(uint32_t &id1, uint32_t &id2)
        : one(id1), two(id2)
    {
        piece[0] = 'X';
        piece[1] = 'O';
        memset(board, ' ', sizeof(board));
        result = 'N';
        current = one;
        pthread_mutex_init(&lock, NULL);
    }
    void Board(string &_board)
    {
        for (auto i = 0; i < SIZE; i++)
        {
            for (auto j = 0; j < SIZE; j++)
            {
                _board.push_back(board[i][j]);
            }
        }
    }
    char Piece(uint32_t &id)
    {
        int pos = (id == one ? 0 : 1);
        return piece[pos];
    }
    bool IsMyTurn(uint32_t &id)
    {
        return id == current ? true : false;
    }
    void Step(uint32_t &id, int &x, int &y)
    {
        if (current == id)
        {
            int pos = (id == one ? 0 : 1);
            board[x][y] = piece[pos];
            current = (id == one ? two : one);
            result = Judge(x, y);
        }
    }
    char GameResult(uint32_t &id)
    {
        return result;
    }
    char Judge(int x, int y)
    {
        int DX[4] = {1, 0, 1, 1};
        int DY[4] = {0, 1, 1, -1};
        char a = board[x][y];
        int k, c1, c2, xx, yy;
        for (k = 0; k < 4; k++)
        {
            c1 = c2 = 0;
            // 如果当前棋子类型与本方向上的棋子是同一类则，继续判断
            // 正方向逐个比较
            for (xx = x + DX[k], yy = y + DY[k]; board[xx][yy] == a && xx<SIZE && yy<SIZE; xx += DX[k], yy += DY[k])
            {
                c1++;
            }
            // 相反方向逐个比较
            for (xx = x - DX[k], yy = y - DY[k]; board[xx][yy] == a && xx>-1 && yy>-1; xx -= DX[k], yy -= DY[k])
            {
                c2++;
            }

            if (c1 + c2 >= 4)
            { 
                return a;
            }
        }
        for (auto i = 0; i < SIZE; i++)
        {
            for (auto j = 0; j < SIZE; j++)
            {
                if (board[i][j] == ' ')
                    return 'N';
            }
        }
        return 'E';
    }
    ~Room()
    {
        pthread_mutex_destroy(&lock);
    }
};
