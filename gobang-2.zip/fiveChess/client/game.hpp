#pragma once

#include <stdio.h>
#include <iostream>
#include <rpc_client.hpp>
#include <chrono>
#include <stdlib.h> //atoi
#include <string>
#include <fstream>
#include <unistd.h>
#include "codec.h"
#include "chessai.hpp"

using namespace std;
using namespace std::chrono_literals;
using namespace rest_rpc;
using namespace rest_rpc::rpc_service;

/* 按键输入枚举 */
enum Key_e
{
    UP,     // 上
    DOWN,   // 下
    LEFT,   // 左
    RIGHT,  // 右
    QUIT,   // 退出
    ENTER,  // 确认
    UNKNOW // 其它
};

uint32_t Register(const string &ip, const int &port, string &name, string &passwd, uint32_t &id)
{
    cout << "请输入昵称 : ";
    cin >> name;
    cout << "请输入密码 : ";
    cin >> passwd;
    string passwd_;
    cout << "请确认密码 : ";
    cin >> passwd_;
    if (passwd != passwd_)
    {
        cout << "两次密码不匹配呦！再检查一下吧！" << endl;
        return 1;
    }
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 2;
        }
        id = client.call<uint32_t>("RpcRegister", name, passwd);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
    return 0;
}
uint32_t Login(const string &ip, const int &port)
{
    uint32_t id;
    string passwd;
    cout << "请输入你的登录id : ";
    cin >> id;
    cout << "请输入登录密码 : ";
    cin >> passwd;
    uint32_t result = 0;
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        result = client.call<uint32_t>("RpcLogin", id, passwd);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
    return result;
}

bool PushIdInMatchPool(string &ip, int &port, uint32_t &id) //把id放到匹配池里
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<bool>("RpcPushIdInMatchPool", id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
int CheckReady(string &ip, int &port, uint32_t id)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<int>("RpcPlayerReady", id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
bool PopMatchPool(string &ip, int &port, uint32_t &id)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<bool>("RpcPopMatchPool", id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
    return false;
}
bool Match(string &ip, int &port, uint32_t &id) //真正的匹配
{
    PushIdInMatchPool(ip, port, id); //把id先放到匹配池里
    //周期性的检测状态
    int count = 20;
    while (1)
    {
        int ready = CheckReady(ip, port, id);
        if (ready == 3)
        {
            return true;
        }
        else if (ready == 1)
        {
            cout << "匹配失败！" << endl;
            return false;
        }
        else //等于2，继续匹配
        {
            printf("匹配倒计时：%2d\r", count--);
            fflush(stdout);
            if (count < 0)
            {
                cout << endl;
                cout << "匹配超时！" << endl;
                PopMatchPool(ip, port, id);
                break;
            }
            sleep(1);
        }
    }
    return false;
}
int GetBoard(string &ip, int &port, uint32_t &room_id, string &board)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        board = client.call<string>("RpcBoard", room_id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
uint32_t GetMyRoomId(string &ip, int &port, uint32_t &id)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<uint32_t>("RpcPlayerRoomId", id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
char GetMyPiece(string &ip, int &port, uint32_t &room_id, uint32_t &id)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<char>("RpcPlayerPiece", room_id, id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}

/*
 * 函数名: getInput()
 * 功能描述: 获取用户输入
 * 参数: 无
 * 返回值: 用户输入所对应的整型值
*/
int getInput(void)
{
    int key;
    char ch;
    ch = getchar();
    /* 方向键 */
    if (ch == '\033' && getchar() == '[')
    {
        ch = getchar();
        switch (ch)
        {
        case 'A':
            key = UP;
            break;
        case 'B':
            key = DOWN;
            break;
        case 'C':
            key = RIGHT;
            break;
        case 'D':
            key = LEFT;
            break;
        }
    }
    /* 确认键 */
    else if (ch == '\n')
    {
        key = ENTER;
    }
    /* 退出键 */
    else if (ch == 'q')
    {
        key = QUIT;
    }
    /* 其它键 */
    else
        key = UNKNOW;

    return key;
}

void ShowBoard(string &board, int idx, int idy)
{
    printf("\033[1;1H"); // 定位到第一行第一列
    fflush(stdout);
    printf("\033[36m***移动光标按确认下棋***\033[0m\n\n");
    for (auto i = 0; i < 15; i++)
    {
        printf("    ");
        for (auto j = 0; j < 15; j++)
        {
            /* 光标位置特殊显示 */
            if (i == idy && j == idx)
            {
                switch (board[j * 15 + i])
                {
                case ' ':
                    printf(" \033[5m+\033[0m");
                    break;
                case 'X':
                    printf(" \033[5m@\033[0m");
                    break;
                case 'O':
                    printf(" \033[5m#\033[0m");
                    break;
                }
            }
            /* 光标以外正常显示 */
            else
            {
                switch (board[j * 15 + i])
                {
                case ' ':
                    printf(" +");
                    break;
                case 'X':
                    printf(" \033[40;31m@\033[0m");
                    break;
                case 'O':
                    printf(" \033[40;32m#\033[0m");
                    break;
                }
            }
        }
        putchar('\n');
    }
    fflush(stdout);
}

void ShowBoardAi(int board[15][15], int idx, int idy)
{
    printf("\033[1;1H"); // 定位到第一行第一列
    fflush(stdout);
    printf("\033[36m***移动光标按确认下棋***\033[0m\n\n");
    for (auto i = 0; i < 15; i++)
    {
        printf("    ");
        for (auto j = 0; j < 15; j++)
        {
            if (i != idx || j != idy)
            {
                switch (board[i][j])
                {
                case C_NONE:
                    printf(" +");
                    break;
                case C_BLACK:
                    printf(" \033[40;31m@\033[0m");
                    break;
                case C_WHITE:
                    printf(" \033[40;32m#\033[0m");
                    break;
                }
            }
            else
            {
                switch (board[i][j])
                {
                case C_NONE:
                    printf(" \033[5m+\033[0m");
                    break;
                case C_BLACK:
                    printf(" \033[5m@\033[0m");
                    break;
                case C_WHITE:
                    printf(" \033[5m#\033[0m");
                    break;
                }
            }
        }
        putchar('\n');
    }
    fflush(stdout);
}
bool IsMyTurn(string &ip, int &port, uint32_t &room_id, uint32_t &id)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<bool>("RpcIsMyTurn", room_id, id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
bool PosIsRight(string &board, int x, int y) //判断位置是否已经被占用
{
    int pos = x * 30 + y;
    return board[pos] == ' ' ? true : false;
}
int Step(string &ip, int &port, uint32_t &room_id, uint32_t &id, int x, int y)
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        client.call<void>("RpcStep", room_id, id, x, y);
        return 0;
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}
char Judge(string &ip, int &port, uint32_t &room_id, uint32_t &id) //判断有没有人赢
{
    try
    {
        rpc_client client(ip, port);
        bool r = client.connect();
        if (!r)
        {
            std::cout << "连接超时" << std::endl;
            return 3;
        }
        return client.call<char>("RpcJudge", room_id, id);
    }
    catch (const std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }
}

void PlayGame(string &ip, int &port, uint32_t &id)
{
    cout << "匹配成功，马上开始游戏！" << endl;
    sleep(3);
    int x, y;
    int idx = 0, idy = 0; /* 光标位置 */
    int key1;
    char result = 'N';
    string board;
    uint32_t room_id = GetMyRoomId(ip, port, id);
    if (room_id < 1024)
    {
        return;
    }
    cout << "房间号：" << room_id << endl;
    char piece = GetMyPiece(ip, port, room_id, id);
    cout << "您的棋子为：" << piece << endl;
    printf("\033[2J");      /* 清屏 */
    system("stty -icanon"); /* 关闭缓冲 */
    system("stty -echo");   /* 关闭回显 */
    printf("\033[?25l");    /* 隐藏鼠标 */
    fflush(stdout);         /* 刷新 */
    getchar();
    while (1)
    {
        system("clear");
        GetBoard(ip, port, room_id, board); //获得棋盘
        ShowBoard(board, idx, idy);         //显示棋盘
        if ((result = Judge(ip, port, room_id, id)) != 'N')
        {
            break;
        }
        if (!IsMyTurn(ip, port, room_id, id)) //判断是不是该我走
        {
            cout << "对手正在思考，请稍等|ू ･ω･` )" << endl;
            sleep(2);
            continue;
        }
        //该我走
        cout << "请选择你的落子位置（上下左右键，回车键确定）";
        key1 = getInput();
        switch (key1)
        {
        case UP:
            if (idy > 0)
                idy--;
            break;
        case DOWN:
            if (idy < 14)
                idy++;
            break;
        case LEFT:
            if (idx > 0)
                idx--;
            break;
        case RIGHT:
            if (idx < 14)
                idx++;
            break;
        case ENTER:
            if (!PosIsRight(board, idx, idy)) //判断位置是否已经被占用
            {
                cout << "你输入的位置已经被占用，请重新输入！" << endl;
            }
            else
            {
                Step(ip, port, room_id, id, idx, idy);
            }
            break;
        case QUIT:
            break;
        case UNKNOW:
            continue;
        }
        GetBoard(ip, port, room_id, board);    //获得棋盘
        ShowBoard(board, idx, idy);            //显示棋盘
        result = Judge(ip, port, room_id, id); //判断有没有人赢
        if (result != 'N')                     //有结果了
        {
            break;
        }
    }
    system("stty icanon"); /* 开缓冲 */
    system("stty echo");   /* 开回显 */
    printf("\033[?25h");   /* 显示鼠标 */
    putchar('\n');
    if (result == 'E')
    {
        cout << "平局，都挺好！ヾ(●´∀｀●))" << endl;
    }
    else if (result == piece)
    {
        cout << "太棒了！你赢了！(*^▽^*))" << endl;
    }
    else
    {
        cout << "哎呀，你输了(ಥ_ಥ)),再来一轮吧~" << endl;
    }
}

//人机对战
void PlayGameWithAi()
{
    chessAi ai;           //棋盘放在ai当中
    bool f1 = true;       //判断当前是否为玩家执手
    int su = 2;           //判断是否产生结果,012分别代表黑棋赢，白棋赢，和棋
    int idx = 0, idy = 0; /* 光标位置 */
    for (int i = 0; i < 15; ++i)
        for (int j = 0; j < 15; ++j)
            ai.chesses[i][j] = C_NONE;
    printf("\033[2J");      /* 清屏 */
    system("stty -icanon"); /* 关闭缓冲 */
    system("stty -echo");   /* 关闭回显 */
    printf("\033[?25l");    /* 隐藏鼠标 */
    fflush(stdout);         /* 刷新 */
    getchar();
    while (1)
    {
        system("clear");
        ShowBoardAi(ai.chesses, idx, idy); //显示棋盘
        if (su!=2)
        {
            break;
        }
        if (!f1) //判断是不是该我走
        {
            cout << "电脑也在思考哦|ू ･ω･` )" << endl;
            //ai计算
            ai.nodeNum = 0;
            //找杀棋
            if (!ai.analyse_kill(ai.chesses, 16))
            {
                ai.analyse(ai.chesses, 6, -INT_MAX, INT_MAX);
            }
            pair<int,int> p=ai.decision.pos;
            f1 = !f1;
            ai.chesses[p.first][p.second] = C_WHITE;
            gameResult result = ai.evaluate(ai.chesses).result;
            if (result != R_DRAW)
            {
                su = result;
                break;
            }
            continue;
        }
        //该我走
        cout << "请选择你的落子位置（上下左右键，回车键确定）";
        int key1 = getInput();
        switch (key1)
        {
        case UP:
            if (idx > 0)
                idx--;
            break;
        case DOWN:
            if (idx < 14)
                idx++;
            break;
        case LEFT:
            if (idy > 0)
                idy--;
            break;
        case RIGHT:
            if (idy < 14)
                idy++;
            break;
        case ENTER:
        {
            if (ai.chesses[idx][idy] != C_NONE) //判断位置是否已经被占用
            {
                cout << "你输入的位置已经被占用，请重新输入！" << endl;
            }
            else
            {
                //玩家总是先下的，所以，玩家总是黑棋
                if (f1)
                {
                    f1 = !f1;
                    ai.chesses[idx][idy] = C_BLACK;
                }
            }
            gameResult result = ai.evaluate(ai.chesses).result;
            if (result != R_DRAW)
            {
                su = result;
            }
            break;
        }
        case QUIT:
            break;
        case UNKNOW:
            continue;
        }
        if (su != R_DRAW)
        {
            break;
        }
    }
    bool f2=true;
    for(auto i=0;i<15;i++){
        for(auto j=0;j<15;j++){
            if(ai.chesses[i][j]==C_NONE){
                f2=false;
                break;
            } 
        }
    }
    idx=-1;
    idy=-1;
    system("clear");
    ShowBoardAi(ai.chesses, idx, idy); //显示棋盘
    system("stty icanon"); /* 开缓冲 */
    system("stty echo");   /* 开回显 */
    printf("\033[?25h");   /* 显示鼠标 */
    putchar('\n');
    if(f2) cout << "平局，都挺好！ヾ(●´∀｀●))" << endl;
    if (su == R_BLACK)
    {
        cout << "太棒了！你赢了！(*^▽^*))" << endl;
    }
    else if (su == R_WHITE)
    {
        cout << "哎呀，你输了(ಥ_ಥ)),再来一轮吧~" << endl;
    }
}

void Game(string &ip, int &port, uint32_t &id) //登录成功会来到游戏界面
{
    int select = 0;
    volatile bool quit = false;
    while (!quit)
    {
        cout << "**************************************" << endl;
        cout << "***            1.匹配              ***" << endl;
        cout << "**************************************" << endl;
        cout << "***            2.人机对战          ***" << endl;
        cout << "**************************************" << endl;
        cout << "***            3.退出              ***" << endl;
        cout << "**************************************" << endl;
        cout << "请选择操作 : ";
        cin >> select;
        switch (select)
        {
        case 1:
        {
            if (Match(ip, port, id))
            { //匹配成功进入游戏
                PlayGame(ip, port, id);
            }
            else
            { //匹配失败提示玩家匹配失败
                cout << "哎呦！匹配失败啦！再试一次吧！" << endl;
            }
        }
        break;
        case 2:
            PlayGameWithAi();
            break;
        case 3:
            quit = true;
            break;
        default:
            cout << "哎呦！你的选择有误，再试一次吧！" << endl;
            break;
        }
    }
}
